﻿using FirstAPI.Contexts;
using FirstAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace FirstAPI.Repositories
{
    public class EmployeeRepository : Repository<int, Employee>
    {
        public EmployeeRepository(EmployeeManagementContext context) : base(context) { }

        public override async Task<Employee> GetById(int key)
        {
            var employee = await _employeeManagementContext.Employees
                .SingleOrDefaultAsync(e => e.Id == key);

            if (employee == null)
                throw new Exception($"Employee with ID {key} not present");

            return employee;
        }

        public override async Task<IEnumerable<Employee>> GetAll()
        {

            var employees = _employeeManagementContext.Employees.Include(e => e.Department);
            if (employees.Count() == 0)
                throw new Exception("No employees found");

            return employees;
        }
    }
}
