﻿using Microsoft.EntityFrameworkCore.Migrations;
using FirstAPI.Interfaces;
using FirstAPI.Contexts;

namespace FirstAPI.Repositories
{
    public  abstract class Repository<K,T>:IRepository<K,T> where T : class
    {
        protected readonly EmployeeManagementContext _employeeManagementContext;
        public Repository(EmployeeManagementContext employeeManagementContext)
        {
            _employeeManagementContext = employeeManagementContext;
        }
        public abstract Task<IEnumerable<T>> GetAll();


        public abstract Task<T> GetById(K key);


        public async Task<T> Add(T entity)
        {
            _employeeManagementContext.Add(entity);
            await _employeeManagementContext.SaveChangesAsync();
            return entity;
        }

        public async Task<T> Update(K key, T entity)
        {
            var data = await GetById(key);
            if (data == null)
                throw new Exception($"Entity with the {key} not present");
            _employeeManagementContext.Entry(data).CurrentValues.SetValues(entity);
            await _employeeManagementContext.SaveChangesAsync();
            return data;
        }

        public async Task<T> Delete(K key)
        {
            var data = await GetById(key);
            if (data == null)
                throw new Exception($"Entity with the {key} not present");
            _employeeManagementContext.Remove(data);
            await _employeeManagementContext.SaveChangesAsync();
            return data;
        }
    

    }
}
