﻿using FirstAPI.Contexts;
using FirstAPI.Models;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;

namespace FirstAPI.Repositories
{
    public class DepartmentRepository : Repository<int, Department>
    {
        public DepartmentRepository(EmployeeManagementContext context) : base(context)
        {
        }

        public override async Task<Department> GetById(int key)
        {
            var department = _employeeManagementContext.Departments.Include(d=>d.Employees).FirstOrDefault(d => d.Id == key);
            if (department == null)
                throw new Exception($"Department with ID {key} not present");
            return department;
        }

        public override async Task<IEnumerable<Department>> GetAll()
        {
            var departments = _employeeManagementContext.Departments.Include(d => d.Employees);//eager loading - Join in SQL terms
            if (!departments.Any())
                throw new Exception("No departments found");
            return await departments.ToListAsync();
        }
    }
}
