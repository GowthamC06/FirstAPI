﻿namespace FirstAPI.Models
{
    public class EmployeeSalary
    {
        public int EmloyeeSalaryId { get; set; }
        public int EmployeeId { get; set; }

    }
}
