﻿namespace FirstAPI.Models.DTOs
{
    public class CreateEmployeeResponse
    {
        public int Id { get; set; }
    }
}
